package baxley.ryan.soundlist;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/* Info screen class */
public class InfoActivity extends AppCompatActivity {

    /* Launches info screen */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
    }

    /* Closes info screen */
    public void done(View view){
        finish();
    }

}
