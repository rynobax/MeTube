package baxley.ryan.soundlist;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.io.File;

/* Activity for saving a recorded sound */
public class SaveActivity extends AppCompatActivity {
    private static final String TAG = "SaveActivity";
    private String soundLocation;
    private final String tempFolder = "/SoundListTemp";
    private SoundsDbHelper mDbHelper;

    /* Launches SaveActivity layout */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save);
        mDbHelper = new SoundsDbHelper(this);
        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        if(bd != null)
        {
            soundLocation = (String) bd.get("soundLocation");
            Log.v(TAG, "soundLocation: " + soundLocation);
        }
    }

    /* Grabs sound out of temp folder, places it in permanent folder, and adds it to the db */
    public void saveSound(View view){
        EditText nameText = (EditText) findViewById(R.id.saveName);
        String name = nameText.getText().toString();
        Log.v(TAG, "STRING IS: " + name);
        /* Empty name */
        if(name.isEmpty()){
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(R.string.blank_name_header);
            alertDialogBuilder
                    .setMessage(R.string.blank_name_message)
                    .setCancelable(false)
                    .setNeutralButton(R.string.ok, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
        /* Name already in use */
        else if(EditActivity.inUse(mDbHelper, name)){
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(R.string.in_use_name_header);
            alertDialogBuilder
                    .setMessage(R.string.in_use_name_message)
                    .setCancelable(false)
                    .setNeutralButton(R.string.ok, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
        /* Valid name */
        else {
            String fileName = name.replaceAll(" ", "_").toLowerCase();

            String finalLocation = Environment.getExternalStorageDirectory().getAbsolutePath() +
                    "/SoundListRecordings/" + fileName + ".3gp";
            File newLocation = new File(finalLocation);
            Integer i = 1;
            while(newLocation.exists()){
                finalLocation= Environment.getExternalStorageDirectory().getAbsolutePath() +
                        "/SoundListRecordings/" + fileName + "_" + i + ".3gp";
                newLocation = new File(finalLocation);
            }

            /* Get the returned data */

            /* Add to db */
            SQLiteDatabase db = mDbHelper.getWritableDatabase();

            // Create a new map of values, where column names are the keys
            ContentValues values = new ContentValues();
            values.put(SoundsContract.SoundEntry.COLUMN_NAME_NAME, name);
            values.put(SoundsContract.SoundEntry.COLUMN_NAME_LOCATION, finalLocation);

            // Insert the new row, returning the primary key value of the new row
            db.insert(
                    SoundsContract.SoundEntry.TABLE_NAME,
                    null,
                    values);

            Log.v(TAG, "Added " + name + " at " + finalLocation);
            deleteTempFiles();
            finish();
        }
    }

    /* Informs user that their sound will be lost if they return */
    @Override
    public void onBackPressed() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle(R.string.are_you_sure);
        alertDialogBuilder
                .setMessage(R.string.lose_sound_alert_header)
                .setCancelable(false)
                .setPositiveButton(R.string.yes,new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        Intent i = getIntent();
                        setResult(RESULT_CANCELED, i);
                        deleteTempFiles();
                        finish();
                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    /* Iterates through temp file folder deleting everything it finds */
    private void deleteTempFiles(){
        File dir = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + tempFolder);
        if (dir.isDirectory())
        {
            String[] children = dir.list();
            for(String child : children)
                new File(dir, child).delete();
        }
    }
}
