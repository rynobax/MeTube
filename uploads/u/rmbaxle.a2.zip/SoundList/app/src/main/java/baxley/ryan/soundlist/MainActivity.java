package baxley.ryan.soundlist;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ListView;

import java.io.File;

/* Home screen for app */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 102;

    private SoundsDbHelper mDbHelper;
    private SoundDatabaseAdapter soundDatabaseAdapter;

    /* Launches MainActivity */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkExternalPermissions();

        createFolders();

        ListView myListView = (ListView) findViewById(R.id.listOfSounds);

        mDbHelper = new SoundsDbHelper(this);

        soundDatabaseAdapter = new SoundDatabaseAdapter(mDbHelper, this);

        myListView.setAdapter(soundDatabaseAdapter);
    }

    /* Launches info screen */
    public void launchInfo(View view){
        Intent myIntent = new Intent(MainActivity.this, InfoActivity.class);
        startActivity(myIntent);
    }

    /* Launches add sound screen */
    public void addSound(View view){
        Intent myIntent = new Intent(MainActivity.this, RecordActivity.class);
        startActivityForResult(myIntent, 1);
    }

    /* We are returning to the main screen so update the table */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        refreshList();
    }

    /* Call to update the listview when the dataset has changed */
    private void refreshList(){
        soundDatabaseAdapter.refreshCursor();
        ListView myListView = (ListView) findViewById(R.id.listOfSounds);
        myListView.setAdapter(null);
        myListView.setAdapter(soundDatabaseAdapter);

        File folder = new File(Environment.getExternalStorageDirectory().getAbsolutePath() +
                "/SoundListRecordings/");
        File tempfolder = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/SoundListTemp/");
        String[] Realfiles = folder.list();
        String[] Tempfiles = tempfolder.list();
        Log.v(TAG, "Folder has " + Realfiles.length + " , while temp has " + Tempfiles.length);
    }

    /* Creates temp and permanent folders */
    private void createFolders(){
        File folder = new File(Environment.getExternalStorageDirectory().getAbsolutePath() +
                "/SoundListRecordings/");
        folder.mkdir();
        File tempfolder = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/SoundListTemp/");
        tempfolder.mkdir();
    }

    /* Requests permission to write to external storage if needed */
    private void checkExternalPermissions(){
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

            } else {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
            }
        }
    }

    /* Handles response from requesting file writing permissions */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {
                    Intent i = getIntent();
                    setResult(RESULT_CANCELED, i);
                    finish();
                }
            }
        }
    }
}