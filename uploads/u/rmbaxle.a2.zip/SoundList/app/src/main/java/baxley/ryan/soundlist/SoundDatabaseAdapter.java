package baxley.ryan.soundlist;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;

/**
 * Listview adapter class for SQLite database
 */
public class SoundDatabaseAdapter extends BaseAdapter implements ListAdapter {
    private static final String TAG = "SoundDatabaseAdapter";
    private final SoundsDbHelper mDbHelper;
    private Cursor cursor;
    private final Context context;



    public SoundDatabaseAdapter(SoundsDbHelper mDbHelper, Context context) {
        this.mDbHelper = mDbHelper;
        this.context = context;
        refreshCursor();
    }

    /* Updates cursor to contain the whole database */
    public void refreshCursor(){
        String[] columns = {
                SoundsContract.SoundEntry._ID,
                SoundsContract.SoundEntry.COLUMN_NAME_NAME,
                SoundsContract.SoundEntry.COLUMN_NAME_LOCATION,
        };

        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        this.cursor = db.query(
                SoundsContract.SoundEntry.TABLE_NAME,  // The table to query
                columns,                               // Return requested columns
                null,                                // Return all rows
                null,                            // No row ards
                null,                                     // Don't group the rows
                null,                                     // Don't filter by row groups
                SoundsContract.SoundEntry.COLUMN_NAME_NAME + " ASC" // The sort order
        );
    }

    /* Returns number of elements in the cursor */
    @Override
    public int getCount() {
        return cursor.getCount();
    }

    /* Gets sound's name */
    @Override
    public Object getItem(int pos) {
        cursor.moveToPosition(pos);
        return cursor.getString(cursor.getColumnIndex("name"));
    }

    /* Gets sound's id */
    @Override
    public long getItemId(int pos) {
        cursor.moveToPosition(pos);
        return cursor.getInt(cursor.getColumnIndex("_id"));
    }

    /* Assigns view */
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        cursor.moveToPosition(position);
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.sounds_listview, null);
        }

        //Handle TextView and display string from your list
        TextView listItemText = (TextView)view.findViewById(R.id.sound_list_item_string);
        listItemText.setText(cursor.getString(cursor.getColumnIndex("name")));

        //Handle buttons and add onClickListeners
        Button deleteBtn = (Button)view.findViewById(R.id.delete_btn);
        Button editBtn = (Button)view.findViewById(R.id.edit_btn);

        listItemText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cursor.moveToPosition(position);
                String soundLocation = cursor.getString(cursor.getColumnIndex("location"));
                Log.v(TAG, "Playing: " + soundLocation);
                MediaPlayer myMediaPlayer = new MediaPlayer();
                try {
                    myMediaPlayer.setDataSource(soundLocation);
                } catch (IOException e) {
                    e.printStackTrace();
                    return;
                }
                try {
                    myMediaPlayer.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                myMediaPlayer.start();
            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // Delete button
                cursor.moveToPosition(position);
                final File file = new File(cursor.getString(cursor.getColumnIndex("location")));

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
                alertDialogBuilder.setTitle("Deleting " + cursor.getString(cursor.getColumnIndex("name")));
                alertDialogBuilder
                        .setMessage("Are you sure you want to delete " +
                                cursor.getString(cursor.getColumnIndex("name")) + "?")
                        .setCancelable(false)
                        .setPositiveButton(R.string.yes,new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                                file.delete();
                                SQLiteDatabase db = mDbHelper.getReadableDatabase();
                                db.delete(SoundsContract.SoundEntry.TABLE_NAME,
                                        SoundsContract.SoundEntry._ID + "=" + getItemId(position),
                                        null);
                                refreshCursor();
                                notifyDataSetChanged();
                            }
                        })
                        .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
        });
        editBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // Edit button
                // Removed updatedb
                cursor.moveToPosition(position);
                Intent myIntent = new Intent(context, EditActivity.class);
                myIntent.putExtra("id", cursor.getInt(cursor.getColumnIndex("_id")));
                ((Activity)context).startActivityForResult(myIntent, 3);
            }
        });

        return view;
    }
}
