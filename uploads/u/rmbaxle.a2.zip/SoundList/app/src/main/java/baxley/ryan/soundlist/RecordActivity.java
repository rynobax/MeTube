package baxley.ryan.soundlist;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.IOException;
import java.util.concurrent.Semaphore;

/* Activity for recording a new sound */
public class RecordActivity extends AppCompatActivity {
    private MediaRecorder myAudioRecorder;
    private String tempFile = null;
    private static final String TAG = "RecordActivity";
    private Integer count;
    private final Semaphore depressing = new Semaphore(1, true);
    private boolean anythingRecorded;

    private static final int MY_PERMISSIONS_REQUEST_RECORD_AUDIO = 101;

    /* Launches new RecordActivity */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);

        anythingRecorded = false;
        count = 0;

        final ImageButton recordButton = (ImageButton) findViewById(R.id.recordButton);
        final ImageView recordButtonDark = (ImageView) findViewById(R.id.recordButtonDark);

        requestAudioPermissions();

        recordButton.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    depressing.acquireUninterruptibly();
                    recordButtonDark.setAlpha(1.0F);
                    tempFile = Environment.getExternalStorageDirectory().getAbsolutePath() +
                            "/SoundListTemp/" + count + ".3gp";
                    myAudioRecorder = new MediaRecorder();
                    myAudioRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                    myAudioRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                    myAudioRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
                    myAudioRecorder.setOutputFile(tempFile);
                    try {
                        myAudioRecorder.prepare();
                    } catch (IOException e) {
                        Log.v(TAG, "IOException: " + e.getMessage());
                        return true;
                    }
                    myAudioRecorder.start();
                    depressing.release();
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    depressing.acquireUninterruptibly();
                    myAudioRecorder.release();
                    anythingRecorded = true;
                    count++;
                    recordButtonDark.setAlpha(0.0F);
                    depressing.release();
                }
                return true;
            }
        });
    }

    /* Attempts to listen to the last recorded sound */
    public void listenToSound(View view){
        if(!anythingRecorded){
            Context context = getApplicationContext();
            CharSequence text = "You haven't recorded anything yet!";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }else{
            MediaPlayer myMediaPlayer = new MediaPlayer();
            try {
                myMediaPlayer.setDataSource(tempFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                myMediaPlayer.prepare();
            } catch (IOException e) {
                e.printStackTrace();
            }
            myMediaPlayer.start();
        }
    }

    /* Attempts to save the last recorded sound */
    public void saveSound(View view){
        if(!anythingRecorded){
            /* Change to alert */
            Context context = getApplicationContext();
            CharSequence text = "You haven't recorded anything yet!";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }else{
            finish();
            Intent myIntent = new Intent(RecordActivity.this, SaveActivity.class);
            myIntent.putExtra("soundLocation",tempFile);
            startActivity(myIntent);
        }
    }

    /* Informs user that their sound will be lost if they return */
    @Override
    public void onBackPressed() {
        if(!anythingRecorded){
            Intent i = getIntent();
            setResult(RESULT_CANCELED, i);
            finish();
        }else {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(R.string.are_you_sure);
            alertDialogBuilder
                    .setMessage(R.string.lose_sound_alert_header)
                    .setCancelable(false)
                    .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Intent i = getIntent();
                            setResult(RESULT_CANCELED, i);
                            finish();
                        }
                    })
                    .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
    }

    /* Requests permission to record audio */
    private void requestAudioPermissions(){
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.RECORD_AUDIO)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.RECORD_AUDIO},
                        MY_PERMISSIONS_REQUEST_RECORD_AUDIO);
            }
        }
    }

    /* Handles result from requesting audio recording permission */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_RECORD_AUDIO: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {
                    Intent i = getIntent();
                    setResult(RESULT_CANCELED, i);
                    finish();
                }
            }
        }
    }

}
