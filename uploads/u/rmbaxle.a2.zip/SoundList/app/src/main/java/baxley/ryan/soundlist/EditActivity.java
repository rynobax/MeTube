package baxley.ryan.soundlist;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

/* Activity for recording a new sound */
public class EditActivity extends AppCompatActivity {
    private static final String TAG = "SoundDatabaseAdapter";
    private Integer id;
    private SoundsDbHelper mDbHelper;
    private String original_name;

    /* Launches EditActivity */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        mDbHelper = new SoundsDbHelper(this);
        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        if(bd != null)
        {
            id = (Integer) bd.get("id");
        }

        String[] columns = {
                SoundsContract.SoundEntry._ID,
                SoundsContract.SoundEntry.COLUMN_NAME_NAME,
                SoundsContract.SoundEntry.COLUMN_NAME_LOCATION,
        };

        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        Cursor c = db.query(
                SoundsContract.SoundEntry.TABLE_NAME,  // The table to query
                columns,                               // Return requested columns
                SoundsContract.SoundEntry._ID + "=" + id, // Return all rows
                null,                                   // No row args
                null,                                     // Don't group the rows
                null,                                     // Don't filter by row groups
                null                                    // The sort order
        );
        c.moveToFirst();
        String name = c.getString(c.getColumnIndex("name"));
        c.close();

        EditText textView = (EditText) findViewById(R.id.editName);
        textView.setText(name);
        original_name = name;
    }

    /* Checks if the requested name already exists in the database */
    public static boolean inUse(SoundsDbHelper helper, String name){
        String[] columns = {
                SoundsContract.SoundEntry._ID,
                SoundsContract.SoundEntry.COLUMN_NAME_NAME,
                SoundsContract.SoundEntry.COLUMN_NAME_LOCATION,
        };
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(
                SoundsContract.SoundEntry.TABLE_NAME,  // The table to query
                columns,                               // Return requested columns
                "LOWER(" + SoundsContract.SoundEntry.COLUMN_NAME_NAME + ") = LOWER(\"" + name + "\")", // Return all rows
                null,                            // No row ards
                null,                                     // Don't group the rows
                null,                                     // Don't filter by row groups
                null                                        // The sort order
        );
        Log.v(TAG, "c.getcount() = " + c.getCount());
        if(c.getCount() > 0){
            c.close();
            return true;
        }else {
            c.close();
            return false;
        }
    }

    /* Attempts to change a sound's name */
    public void editSound(View view){
        EditText textView = (EditText) findViewById(R.id.editName);
        String name = textView.getText().toString();
        if(name.isEmpty()) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(R.string.blank_name_header);
            alertDialogBuilder
                    .setMessage(R.string.blank_name_message)
                    .setCancelable(false)
                    .setNeutralButton(R.string.ok, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
        else if(inUse(mDbHelper, name) && (name.compareToIgnoreCase(original_name) != 0)){
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(R.string.in_use_name_header);
            alertDialogBuilder
                    .setMessage(R.string.in_use_name_message)
                    .setCancelable(false)
                    .setNeutralButton(R.string.ok, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
        else{
            SQLiteDatabase db = mDbHelper.getWritableDatabase();

            ContentValues cv = new ContentValues();
            cv.put("name", name);

            db.update(SoundsContract.SoundEntry.TABLE_NAME,
                    cv,
                    SoundsContract.SoundEntry._ID + "=" + id,
                    null);

            Intent i = getIntent();
            setResult(RESULT_OK, i);
            finish();
        }
    }

}
