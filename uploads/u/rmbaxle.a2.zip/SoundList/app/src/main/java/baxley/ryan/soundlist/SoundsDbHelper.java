package baxley.ryan.soundlist;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Helper class to create and manage the sound database
 */
public class SoundsDbHelper extends SQLiteOpenHelper {
    private static final String TEXT_TYPE = " TEXT";
    private static final String COMMA_SEP = ",";
    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + SoundsContract.SoundEntry.TABLE_NAME + " (" +
                    SoundsContract.SoundEntry._ID+ " INTEGER PRIMARY KEY," +
                    SoundsContract.SoundEntry.COLUMN_NAME_NAME + TEXT_TYPE + COMMA_SEP +
                    SoundsContract.SoundEntry.COLUMN_NAME_LOCATION + TEXT_TYPE +
                    " )";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + SoundsContract.SoundEntry.TABLE_NAME;

    // If you change the database schema, you must increment the database version.
    private static final int DATABASE_VERSION = 3;
    private static final String DATABASE_NAME = "Sounds.db";

    /* Calls SQLiteOpenHelper's constructor */
    public SoundsDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    /* Creates database */
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }
    /* Upgrade policy is to discard old entries and create a fresh database */
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
    /* Downgrade policy is to discard old entries and create a fresh database */
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
}