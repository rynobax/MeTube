package baxley.ryan.soundlist;

import android.provider.BaseColumns;

/**
 * Contains info about the sound SQLite database
 */
public final class SoundsContract {
    public SoundsContract() {}

    /* Defines the table contents */
    public static abstract class SoundEntry implements BaseColumns {
        /* Table name */
        public static final String TABLE_NAME = "sounds";
        public static final String COLUMN_NAME_NAME = "name";
        public static final String COLUMN_NAME_LOCATION = "location";
    }

}
